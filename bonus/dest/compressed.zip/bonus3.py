'''meals = ['pasta','pizza','salad']

for item in meals:
    print(item.capitalize())'''

m = ['a','b','c']
print(m.pop(1))